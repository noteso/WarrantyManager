const { Component, Mixin } = Shopware;
const { Criteria } = Shopware.Data;

import template from './warranty-manager-list.html.twig';

Component.register('warranty-manager-list', {
    inject: ['repositoryFactory'],

    template,

    metaInfo(){
        return{
            title: this.$createTitle()
        };
    },

    data() {
        return {
            total: 0,
            warrantyManagerCollection: null,
            repository: null,
            isLoading:false,
            processSuccess:false,
            fileContent: null,
            showModal: false,
            isModalLoading: false,
        };
    },

    created() {
        this.getWarrantyManager();
    },

    computed: {
        columns() {
            return [{
                property: 'productName',
                dataIndex: 'product.name',
                label: "Product",
                allowResize: true,
                sortable: false,
            },
            {
                property: 'customerName',
                dataIndex: 'customer.lastName,customer.firstName',
                label: "Customer",
                allowResize: true,
                sortable: false,
            },
            {
                property: 'warrantyDuration',  // column property
                dataIndex: 'warrantyDuration',
                label: "Warranty Duration", // column label (snippets used for labels)
                allowResize: true,
                sortable: false,
            }
            ];
        }
    },

    methods: {
        getWarrantyManager: function () {
            const criteria = new Criteria()
                .addAssociation('product')
                .addAssociation('customer');
            this.repository = this.repositoryFactory.create('product_warranty'); // product repository data
            this.repository.search(criteria, Shopware.Context.api).then((result) =>{
                this.warrantyManagerCollection = result;
                this.total = result.total;
            })
        },
        openModal(){
            this.showModal = true;
            this.getWarrantyManager();
        },
        closeModal(){
            this.showModal = false;
        },
        exportCSV(){
            this.isModalLoading = true;

            this.getWarrantyManager();
            
            this.fileContent = "";
            this.warrantyManagerCollection.forEach(entity => {
                this.fileContent += entity.productId + "," + entity.customerId + "," + entity.warrantyText + "," + entity.warrantyDuration + "\n"
            });

            const blob = new Blob([this.fileContent], { type: 'text/csv' });
            const url = URL.createObjectURL(blob);
            

            const link = document.createElement('a');
            link.href = url;
            link.setAttribute('download', 'export.csv');
            const modal = document.querySelector(".csvexport")
            modal.appendChild(link);
            link.click();
            modal.removeChild(link);
            this.closeModal();
        },
    }
});