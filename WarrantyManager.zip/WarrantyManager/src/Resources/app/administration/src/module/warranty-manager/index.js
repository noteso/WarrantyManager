import deDE from './snippet/de-DE.json';
import enGB from './snippet/en-GB.json';

import './page/warranty-manager-list';
import './page/warranty-manager-edit';
import './page/warranty-manager-create';

Shopware.Module.register('warranty-manager', {
    type: 'plugin',
    name: 'Warranty Manager',
    title: 'warranty-manager.general.mainMenuItemGeneral',
    description: 'warranty-manager.general.descriptionTextModule',
    color: '#ff3d58',

    snippets: {
        'de-DE': deDE,
        'en-GB': enGB
    },

    navigation: [{
        id: 'warranty-manager',
        label: 'warranty-manager.general.mainMenuItemGeneral',
        color: '#ff3d58',
        path: 'warranty.manager.list',
        parent: 'sw-customer',
        position: 100
    }],

    routes: {
        list: {
            component: 'warranty-manager-list',
            path: 'list'
        },
        edit:{
            component: 'warranty-manager-edit',
            path: 'edit/:id',
            meta: {
                parentPath: 'warranty.manager.list'
            }
        },
        create: {
            component: 'warranty-manager-create',
            path: 'create',
            meta:{
                parentPath: 'warranty.manager.list'
            }
        }
    }
});