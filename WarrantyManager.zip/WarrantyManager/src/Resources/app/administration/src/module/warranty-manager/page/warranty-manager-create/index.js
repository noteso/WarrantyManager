const { Component, Mixin } = Shopware;

import template from './warranty-manager-create.html.twig';

Component.register('warranty-manager-create', {
    inject: ['repositoryFactory'],    
    
    template,

    data() {
        return {
            warranty: null,
            isSaveSuccessful: false,
            isLoading: false,
            selectedFile: null,
            content: null,
            showModal: false
        };
    },

    computed: {
        warrantyRepository() {
            return this.repositoryFactory.create('product_warranty');
        },

        productRepository() {
            return this.repositoryFactory.create('product');
        },

        customerRepository() {
            return this.repositoryFactory.create('customer');
        }
    },

    created() {
        this.createdComponent();
    },
    
    methods: {
        createdComponent() {
            this.warranty = this.warrantyRepository.create();

        },
    
        saveFinish() {
            this.isSaveSuccessful = false;
            this.$router.push({ name: 'warranty.manager.list' });
            console.log("finnished saving lol");
        },
    
        async onSave() {
            this.isLoading = true;
    
            this.isSaveSuccessful = false;

            this.productRepository
                .get(this.warranty.productId, Shopware.Context.api)
                .then(product => {
                    this.warranty.product = product;
                });
                
            this.customerRepository
                .get(this.warranty.customerId, Shopware.Context.api)
                .then(customer => {
                    this.warranty.customer = customer
                });
                
            
            return this.warrantyRepository.save(this.warranty, Shopware.Context.api).then((response) => {
                this.isLoading = false;
                this.isSaveSuccessful = true;

                return response;
            }).catch((e) => {
                    //this.createNotificationError({
                    //message: this.$tc('sw-customer.detail.messageSaveError'),
                //});
                console.log(e);
                this.isLoading = false;
            });
            
        },
        readFile() {
            const reader = new FileReader();
            if (this.selectedFile.name.includes(".csv")) {
              reader.onload = (res) => {
                this.content = res.target.result;
                this.importData(this.content)
              };
              reader.onerror = (err) => console.log(err);
              reader.readAsText(this.selectedFile);
            } else {
              this.content = "check the console for file output";
              reader.onload = (res) => {
                console.log(content);
                console.log(res.target.result);
              };
              reader.onerror = (err) => console.log(err);
              reader.readAsText(this.selectedFile);
            }
        },
        importData(content){
            this.isLoading = true;
            let lines = content.split('\n');

            lines.forEach(line => {
                console.log("I am here again");
                let warranty = null
                warranty = this.warrantyRepository.create();

                let fields = line.split(',');
                if(fields[0] !== ""){
                    warranty.productId = fields[0];
                    warranty.customerId = fields[1];
                    warranty.warrantyText = fields[2];
                    warranty.warrantyDuration = parseInt(fields[3], 10);

                    this.productRepository
                        .get(warranty.productId, Shopware.Context.api)
                        .then(product => {
                            warranty.product = product;
                        });
                        
                    this.customerRepository
                        .get(warranty.customerId, Shopware.Context.api)
                        .then(customer => {
                            warranty.customer = customer
                        });
                        
                    
                    this.warrantyRepository.save(warranty, Shopware.Context.api).then((response) => {

                    }).catch((e) => {
                            //this.createNotificationError({
                            //message: this.$tc('sw-customer.detail.messageSaveError'),
                        //});
                        console.log(e);
                    });
                }
            });
            setTimeout(() => {
                this.isLoading = false;
                this.$router.push({ name: 'warranty.manager.list' });
            },1000);
        }
    },
})