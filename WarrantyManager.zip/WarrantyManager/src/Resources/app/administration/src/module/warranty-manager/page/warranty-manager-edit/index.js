const { Component, Mixin } = Shopware;
import template from './warranty-manager-edit.html.twig';
Component.register('warranty-manager-edit', {
    inject: ['repositoryFactory'],    
    
    template,

    data() {
        return {
            warranty: null,
            isSaveSuccessful: false,
            isLoading: false,
            warrantyId: this.$route.params.id,
        };
    },

    computed: {
        warrantyRepository() {
            return this.repositoryFactory.create('product_warranty');
        },

        productRepository() {
            return this.repositoryFactory.create('product');
        },

        customerRepository() {
            return this.repositoryFactory.create('customer');
        }
    },

    created() {
        this.warrantyRepository
                .get(this.warrantyId, Shopware.Context.api)
                .then(entity => {
                    this.warranty = entity;
                });
    },
    
    methods: {
        createdComponent() {
            this.warrantyRepository
                .get(this.warrantyId, Shopware.Context.api)
                .then(entity => {
                    this.warranty = entity;
                });
        },
    
        saveFinish() {
            this.isSaveSuccessful = false;
            this.$router.push({ name: 'warranty.manager.list' });
        },
    
        async onSave() {
            this.isLoading = true;
    
            this.isSaveSuccessful = false;

            this.productRepository
                .get(this.warranty.productId, Shopware.Context.api)
                .then(product => {
                    this.warranty.product = product;
                });
                
            this.customerRepository
                .get(this.warranty.customerId, Shopware.Context.api)
                .then(customer => {
                    this.warranty.customer = customer
                });
                
            
            return this.warrantyRepository.save(this.warranty, Shopware.Context.api).then((response) => {
                this.isLoading = false;
                this.isSaveSuccessful = true;

                return response;
            }).catch((e) => {
                    //this.createNotificationError({
                    //message: this.$tc('sw-customer.detail.messageSaveError'),
                //});
                console.log(e);
                this.isLoading = false;
            });
            
        },
        onCancel(){
            this.$router.push({ name: 'warranty.manager.list'});
        },
    },
})