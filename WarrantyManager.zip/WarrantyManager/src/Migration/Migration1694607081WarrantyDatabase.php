<?php declare(strict_types=1);

namespace WarrantyManager\Migration;

use Doctrine\DBAL\Connection;
use Shopware\Core\Framework\Migration\MigrationStep;

class Migration1694607081WarrantyDatabase extends MigrationStep
{
    public function getCreationTimestamp(): int
    {
        return 1694607081;
    }

    public function update(Connection $connection): void
    {
        // implement update
        $sql = <<<SQL
            CREATE TABLE IF NOT EXISTS `product_warranty` (
                `id` BINARY(16) NOT NULL,
                `product_id` BINARY(16) NULL,
                `customer_id` BINARY(16) NULL,
                `warranty_text` TEXT COLLATE utf8mb4_unicode_ci,
                `warranty_duration` INT NOT NULL,
                `created_at` DATETIME(3) NOT NULL,
                `updated_at` DATETIME(3) NULL,
                PRIMARY KEY (`id`),
                KEY `fk.product_warranty.product_id` (`product_id`),
                KEY `fk.product_warranty.customer_id` (`customer_id`),
                CONSTRAINT `fk.product_warranty.product_id` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
                CONSTRAINT `fk.product_warranty.customer_id` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
            ) 
                ENGINE = InnoDB
                DEFAULT CHARSET = utf8mb4
                COLLATE = utf8mb4_unicode_ci;
            SQL;

        $connection->executeStatement($sql);
    }

    public function updateDestructive(Connection $connection): void
    {
        // implement update destructive
    }
}
