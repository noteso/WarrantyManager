<?php declare(strict_types=1);

namespace WarrantyManager;

use Shopware\Core\Framework\Plugin;

class WarrantyManager extends Plugin
{
}