<?php declare(strict_types=1);

namespace WarrantyManager\Core\Content\Warranty;

use Shopware\Core\Framework\DataAbstractionLayer\EntityCollection;

class WarrantyCollection extends EntityCollection {
    protected function getExpectedClass(): string
    {
        return WarrantyEntity::class;
    }
}