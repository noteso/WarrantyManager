<?php declare(strict_types=1);

namespace WarrantyManager\Core\Content\Warranty;

use Shopware\Core\Framework\DataAbstractionLayer\Entity;
use Shopware\Core\Framework\DataAbstractionLayer\EntityIdTrait;
use Shopware\Core\Content\Product\ProductEntity;
use Shopware\Core\Checkout\Customer\CustomerEntity;

class WarrantyEntity extends Entity {
    use EntityIdTrait;

    /**
     * @var string
     */
    protected string $productId;

    /**
     * @var ProductEntity
     */
    protected ?ProductEntity $product = null;

    /**
     * @var string
     */
    protected string $customerId;

    /**
     * @var CustomerEntity
     */
    protected ?CustomerEntity $customer = null;

    /**
     * @var string
     */
    protected string $warrantyText;

    /**
     * @var int
     */
    protected int $warrantyDuration;

    /**
     * @var \DateTimeInterface|null
     */
    protected $createdAt;

    /**
     * @var \DateTimeInterface|null
     */
    protected $updatedAt;

    /**
     * @return string
     */
    public function getProductId(): string
    {
        return $this->productId;
    }

    /**
     * @param string $productId
     */
    public function setProductId(string $productId): void
    {
        $this->productId = $productId;
    }

    /**
     * @return ProductEntity
     */
    public function getProduct(): ProductEntity
    {
        return $this->product;
    }

    /**
     * @param ProductEntity $product
     */
    public function setProduct(ProductEntity $product): void
    {
        $this->product = $product;
    }

    /**
     * @return string
     */
    public function getCustomerId(): string
    {
        return $this->customerId;
    }

    /**
     * @param string $customerId
     */
    public function setCustomerId(string $customerId): void
    {
        $this->customerId = $customerId;
    }

    /**
     * @return CustomerEntity
     */
    public function getCustomer(): CustomerEntity
    {
        return $this->customer;
    }

    /**
     * @param CustomerEntity $customer
     */
    public function setCustomer(CustomerEntity $customer): void
    {
        $this->customer = $customer;
    }

    /**
     * @return string
     */
    public function getWarrantyText(): string
    {
        return $this->warrantyText;
    }

    /**
     * @param string $warrantyText
     */
    public function setWarrantyText(string $warrantyText): void
    {
        $this->warrantyText = $warrantyText;
    }

    /**
     * @return int
     */
    public function getWarrantyDuration(): int
    {
        return $this->warrantyDuration;
    }

    /**
     * @param int $warrantyDuration
     */
    public function setWarrantyDuration(int $warrantyDuration): void
    {
        $this->warrantyDuration = $warrantyDuration;
    }
}