<?php declare(strict_types=1);

namespace WarrantyManager\Extension\Checkout\Customer;

use Shopware\Core\Checkout\Customer\CustomerDefinition;
use Shopware\Core\Framework\DataAbstractionLayer\EntityExtension;
use Shopware\Core\Framework\DataAbstractionLayer\Field\OneToManyAssociationField;
use Shopware\Core\Framework\DataAbstractionLayer\FieldCollection;
use WarrantyManager\Core\Content\Warranty\WarrantyDefinition;

class CustomerExtension extends EntityExtension {
    public function extendFields(FieldCollection $collection): void
    {
        $collection->add(
            new OneToManyAssociationField('warranties', WarrantyDefinition::class, 'customer_id')
        );
    }

    public function getDefinitionClass(): string
    {
        return CustomerDefinition::class;
    }
}